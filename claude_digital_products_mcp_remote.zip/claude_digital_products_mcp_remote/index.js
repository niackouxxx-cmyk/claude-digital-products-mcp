import express from "express";
import { randomUUID } from "node:crypto";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const app = express();
app.use(express.json());

function createServer() {
  const server = new McpServer({
    name: "claude-digital-products",
    version: "1.0.0"
  });

  server.registerTool("market_research_plan", {
    title: "Plan d'étude de marché",
    description: "Crée un plan de recherche de marché. Ne prétend pas avoir effectué de recherche web en direct.",
    inputSchema: {
      idea: z.string().min(3).describe("Idée de produit numérique"),
      audience: z.string().min(2).describe("Public cible")
    }
  }, async ({ idea, audience }) => ({
    content: [{ type: "text", text: [
      "PLAN D'ÉTUDE DE MARCHÉ",
      `Idée : ${idea}`,
      `Public cible : ${audience}`,
      "",
      "1. Définir le problème et le résultat recherché.",
      "2. Comparer 5 à 10 produits concurrents : public, promesse, prix, format.",
      "3. Étudier les avis publics pour repérer les besoins non satisfaits.",
      "4. Interroger des personnes du public cible avant de créer le produit.",
      "5. Tester une page de présentation ou une prévente transparente.",
      "6. Mesurer les inscriptions, retours et achats.",
      "Ne pas inventer de chiffres ni présenter des hypothèses comme des faits."
    ].join("\n") }]
  }));

  server.registerTool("digital_product_outline", {
    title: "Structure de produit numérique",
    description: "Propose un plan pour un ebook, modèle, mini-formation ou pack de ressources.",
    inputSchema: {
      productType: z.string().min(2).describe("Type de produit"),
      topic: z.string().min(2).describe("Sujet"),
      audience: z.string().min(2).describe("Public cible"),
      outcome: z.string().min(2).describe("Résultat concret visé")
    }
  }, async ({ productType, topic, audience, outcome }) => ({
    content: [{ type: "text", text: [
      `PRODUIT : ${topic}`,
      `Format : ${productType}`,
      `Public : ${audience}`,
      `Objectif à valider : ${outcome}`,
      "",
      "Structure proposée :",
      "1. Introduction et objectif",
      "2. Problème et erreurs fréquentes",
      "3. Méthode étape par étape",
      "4. Exemples concrets",
      "5. Modèles, exercices ou checklists",
      "6. Plan d'action sur 7 jours",
      "7. FAQ et limites du produit",
      "Vérifier l'exactitude, les droits et l'accessibilité avant publication."
    ].join("\n") }]
  }));

  server.registerTool("pricing_calculator", {
    title: "Calculateur de prix",
    description: "Estime le reste après frais et coûts indiqués. Taxes non incluses automatiquement.",
    inputSchema: {
      price: z.number().nonnegative().describe("Prix unitaire"),
      sales: z.number().int().nonnegative().describe("Nombre de ventes"),
      feePercent: z.number().min(0).max(100).default(0).describe("Pourcentage de frais"),
      fixedCosts: z.number().nonnegative().default(0).describe("Coûts fixes totaux")
    }
  }, async ({ price, sales, feePercent, fixedCosts }) => {
    const gross = price * sales;
    const fees = gross * feePercent / 100;
    const remainder = gross - fees - fixedCosts;
    return { content: [{ type: "text", text: [
      "ESTIMATION (hors taxes non renseignées)",
      `Chiffre d'affaires brut : ${gross.toFixed(2)}`,
      `Frais estimés : ${fees.toFixed(2)}`,
      `Coûts fixes : ${fixedCosts.toFixed(2)}`,
      `Reste estimé : ${remainder.toFixed(2)}`,
      "Vérifie les frais de plateforme, la TVA et tes obligations fiscales."
    ].join("\n") }] };
  });

  server.registerTool("sales_copy_framework", {
    title: "Trame de page de vente",
    description: "Prépare une trame commerciale sans faux avis ni promesses inventées.",
    inputSchema: {
      product: z.string().min(2).describe("Produit"),
      audience: z.string().min(2).describe("Public cible"),
      problem: z.string().min(2).describe("Problème résolu"),
      features: z.array(z.string()).min(1).describe("Éléments réellement inclus")
    }
  }, async ({ product, audience, problem, features }) => ({
    content: [{ type: "text", text: [
      `PAGE DE VENTE : ${product}`,
      `Pour : ${audience}`,
      `Problème : ${problem}`,
      "",
      "Titre : Avancez vers [résultat réaliste] avec [produit].",
      "Présentation : expliquez clairement ce que le produit permet de faire.",
      "Contenu inclus :",
      ...features.map(x => `- ${x}`),
      "Ajoutez les prérequis, limites, FAQ, prix total et conditions de vente.",
      "N'inventez ni témoignages, ni statistiques, ni garanties."
    ].join("\n") }]
  }));

  server.registerTool("seo_keyword_plan", {
    title: "Plan SEO",
    description: "Crée une stratégie de mots-clés à vérifier dans un outil SEO. Pas de volumes live.",
    inputSchema: {
      product: z.string().min(2).describe("Produit ou sujet"),
      audience: z.string().min(2).describe("Public cible"),
      market: z.string().default("marché francophone").describe("Marché")
    }
  }, async ({ product, audience, market }) => ({
    content: [{ type: "text", text: [
      `PLAN SEO : ${product}`,
      `Public : ${audience} | Marché : ${market}`,
      "Pistes : requête principale, problèmes recherchés, comparaisons, intention d'achat.",
      "Préparer une page produit, une FAQ, un guide pratique et deux articles utiles.",
      "Vérifier volumes, concurrence et intention avec un outil de mots-clés."
    ].join("\n") }]
  }));

  server.registerTool("social_content_calendar", {
    title: "Calendrier de contenu social",
    description: "Crée un calendrier éditorial de promotion.",
    inputSchema: {
      product: z.string().min(2).describe("Produit"),
      platform: z.string().min(2).describe("Réseau social"),
      days: z.number().int().min(3).max(30).default(7).describe("Nombre de jours")
    }
  }, async ({ product, platform, days }) => {
    const themes = [
      "Expliquer un problème du public",
      "Partager une astuce utile",
      "Montrer les coulisses",
      "Répondre à une objection",
      "Donner un exemple réaliste",
      "Partager une mini-checklist",
      "Présenter le produit et ses limites"
    ];
    return { content: [{ type: "text", text: Array.from({length: days}, (_, i) =>
      `Jour ${i + 1} (${platform}) : ${themes[i % themes.length]} — faire le lien avec ${product}.`
    ).join("\n") }] };
  });

  server.registerTool("email_sequence", {
    title: "Séquence d'e-mails",
    description: "Propose une séquence marketing respectueuse du consentement et du désabonnement.",
    inputSchema: {
      product: z.string().min(2).describe("Produit"),
      audience: z.string().min(2).describe("Public cible"),
      count: z.number().int().min(2).max(7).default(4).describe("Nombre d'e-mails")
    }
  }, async ({ product, audience, count }) => {
    const subjects = [
      "Bienvenue et présentation de la méthode",
      "Une difficulté fréquente et comment l'aborder",
      "Une astuce pratique à essayer",
      `Présentation de ${product} : contenu et limites`,
      "Réponses aux questions fréquentes",
      "Exemple d'utilisation",
      "Récapitulatif et prochaines étapes"
    ];
    return { content: [{ type: "text", text: [
      `Séquence pour ${audience} autour de ${product} :`,
      ...subjects.slice(0, count).map((s, i) => `${i + 1}. Objet : ${s}`),
      "Envoyer seulement aux personnes autorisées, identifier l'expéditeur et permettre le désabonnement."
    ].join("\n") }] };
  });

  server.registerTool("licensing_compliance_checklist", {
    title: "Checklist licences et conformité",
    description: "Checklist générale, pas un avis juridique.",
    inputSchema: {
      productType: z.string().min(2).describe("Type de produit"),
      salesRegion: z.string().default("Belgique / Union européenne").describe("Région de vente")
    }
  }, async ({ productType, salesRegion }) => ({
    content: [{ type: "text", text: [
      `CHECKLIST : ${productType}`,
      `Marché : ${salesRegion}`,
      "- Vérifier les droits commerciaux des textes, images, polices et modèles.",
      "- Conserver les licences et preuves d'achat.",
      "- Définir les droits de l'acheteur et interdire clairement la redistribution si nécessaire.",
      "- Vérifier les marques et contenus de tiers.",
      "- Afficher les conditions de vente, le prix et les modalités d'accès.",
      "- Vérifier TVA, droit des consommateurs et protection des données.",
      "- Pour les téléchargements, vérifier les règles de rétractation applicables.",
      "Les obligations varient selon le produit, la plateforme et le pays."
    ].join("\n") }]
  }));

  return server;
}

app.get("/", (_req, res) => {
  res.status(200).send("Claude Digital Products MCP is running. MCP endpoint: /mcp");
});

app.all("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true
  });
  const server = createServer();
  res.on("close", () => {
    transport.close().catch(() => {});
    server.close().catch(() => {});
  });
  try {
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (error) {
    console.error("MCP request error:", error);
    if (!res.headersSent) res.status(500).json({ error: "Internal server error" });
  }
});

const port = process.env.PORT || 10000;
app.listen(port, "0.0.0.0", () => {
  console.log(`MCP server listening on port ${port}`);
});
